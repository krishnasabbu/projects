import matplotlib.pyplot as plt
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
import numpy as np

# Simulate classification data (fix: set n_informative=2, n_redundant=0)
X, y = make_classification(
    n_samples=100,
    n_features=2,
    n_informative=2,
    n_redundant=0,
    n_classes=2,
    random_state=1
)

# Visualize data
plt.scatter(X[:, 0], X[:, 1], c=y, cmap='bwr')
plt.title('Simulated Classification Data')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.grid(True)
plt.show()

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=1)

# Fit model
model = LogisticRegression()
model.fit(X_train, y_train)

# Decision boundary
coef = model.coef_[0]
intercept = model.intercept_

x_vals = np.linspace(X[:, 0].min(), X[:, 0].max(), 100)
y_vals = -(coef[0] * x_vals + intercept) / coef[1]

plt.scatter(X[:, 0], X[:, 1], c=y, cmap='bwr', alpha=0.7)
plt.plot(x_vals, y_vals, color='black', linewidth=2)
plt.title('Logistic Regression Decision Boundary')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.grid(True)
plt.show()