import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
import pandas as pd

# Load Iris dataset
iris = load_iris()
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df['target'] = iris.target

# Pairplot
print("Pairplot of Iris Dataset")
sns.pairplot(df, hue='target')
plt.suptitle('Pairplot of Iris Dataset', y=1.02)
plt.show()

# Boxplot of Features
print("Boxplot of Features by Target")
df_melted = df.melt(id_vars='target', var_name='feature', value_name='value')
sns.boxplot(x='feature', y='value', hue='target', data=df_melted)
plt.xticks(rotation=90)
plt.title('Boxplot of Features by Target')
plt.show()