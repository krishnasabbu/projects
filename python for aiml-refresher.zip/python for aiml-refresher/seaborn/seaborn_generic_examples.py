import seaborn as sns
import matplotlib.pyplot as plt

# Load built-in dataset
tips = sns.load_dataset('tips')

# Histogram
print("Histogram of Total Bill")
sns.histplot(tips['total_bill'], kde=True)
plt.title('Histogram of Total Bill')
plt.show()

# Boxplot
print("Boxplot of Total Bill by Day")
sns.boxplot(x='day', y='total_bill', data=tips)
plt.title('Boxplot by Day')
plt.show()

# Scatter Plot
print("Scatter Plot of Tip vs Total Bill")
sns.scatterplot(x='total_bill', y='tip', data=tips)
plt.title('Scatter Plot')
plt.show()

# Heatmap
print("Correlation Heatmap")
corr = tips.corr(numeric_only=True)
sns.heatmap(corr, annot=True, cmap='coolwarm')
plt.title('Correlation Heatmap')
plt.show()