# Import pandas library
import pandas as pd

# Create DataFrame
print('\n\nCreate DataFrame')
print('------------------------------------------')
data = {'Name': ['Alice', 'Bob', 'Charlie'], 'Age': [25, 30, 35]}
df = pd.DataFrame(data)
print('DataFrame:')
print(df)

# Select Columns
print('\n\nSelect Columns')
print('------------------------------------------')
print('Names column:')
print(df['Name'])

# Filtering Rows
print('\n\nFiltering Rows')
print('------------------------------------------')
print('Rows where Age > 28:')
print(df[df['Age'] > 28])

# Add New Column
print('\n\nAdd New Column')
print('------------------------------------------')
df['Salary'] = [50000, 60000, 70000]
print('DataFrame with Salary column:')
print(df)

# Summary Statistics
print('\n\nSummary Statistics')
print('------------------------------------------')
print('Describe DataFrame:')
print(df.describe())

# Handling Missing Data
print('\n\nHandling Missing Data')
print('------------------------------------------')
df_with_nan = df.copy()
df_with_nan.loc[1, 'Salary'] = None
print('With NaN:')
print(df_with_nan)
print('After filling NaN with 0:')
print(df_with_nan.fillna(0))

# Grouping Data
print('\n\nGrouping Data')
print('------------------------------------------')
df_group = pd.DataFrame({'Department': ['HR', 'HR', 'IT'], 'Salary': [50000, 60000, 70000]})
grouped = df_group.groupby('Department').mean()
print('Grouped by Department:')
print(grouped)

# Sorting Data
print('\n\nSorting Data')
print('------------------------------------------')
print('Sorted by Age:')
print(df.sort_values(by='Age'))

# Reading CSV
print('\n\nReading CSV (Example only, requires actual file)')
print('------------------------------------------')
print('Use: pd.read_csv("filename.csv")')

# Writing CSV
print('\n\nWriting CSV (Example only)')
print('------------------------------------------')
print('Use: df.to_csv("output.csv", index=False)')