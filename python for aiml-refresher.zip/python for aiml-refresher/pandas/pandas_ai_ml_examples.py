# Import pandas and other ML libraries
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Load Dataset into DataFrame
print('\n\nLoad Iris Dataset')
print('------------------------------------------')
iris = load_iris()
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df['target'] = iris.target
print('Iris DataFrame:')
print(df.head())

# Data Summary
print('\n\nData Summary')
print('------------------------------------------')
print('Summary statistics of the dataset:')
print(df.describe())

# Check for Missing Values
print('\n\nCheck for Missing Values')
print('------------------------------------------')
print('Missing values in each column:')
print(df.isnull().sum())

# Filter Specific Class
print('\n\nFilter Specific Class')
print('------------------------------------------')
print('Rows where target == 0 (Setosa):')
print(df[df['target'] == 0].head())

# Group by Target
print('\n\nGroup by Target')
print('------------------------------------------')
print('Mean of each feature per class:')
print(df.groupby('target').mean())

# Feature Engineering: Add Petal Ratio
print('\n\nFeature Engineering')
print('------------------------------------------')
df['petal ratio'] = df['petal length (cm)'] / df['petal width (cm)']
print('Added "petal ratio" column:')
print(df[['petal length (cm)', 'petal width (cm)', 'petal ratio']].head())

# Correlation Matrix
print('\n\nCorrelation Matrix')
print('------------------------------------------')
print('Correlation between features:')
print(df.corr())

# Train-Test Split
print('\n\nTrain-Test Split')
print('------------------------------------------')
X = df.drop('target', axis=1)
y = df['target']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print('Training feature shape:', X_train.shape)
print('Testing feature shape:', X_test.shape)

# Standardization
print('\n\nStandardization')
print('------------------------------------------')
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
print('First 5 rows of standardized training data:')
print(X_train_scaled[:5])

# Save processed data to CSV (Example)
print('\n\nSaving Processed Data')
print('------------------------------------------')
df.to_csv('iris_processed.csv', index=False)
print('Processed data saved to "iris_processed.csv"')