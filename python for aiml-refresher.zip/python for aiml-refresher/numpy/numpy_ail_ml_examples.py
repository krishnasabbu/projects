# Import numpy
import numpy as np

# Example 1: Creating feature arrays
print('\n\nCreate Feature Arrays')
print('------------------------------------------')
features = np.array([[1.2, 3.4], [5.6, 7.8]])
print('Features:')
print(features)

# Example 2: Simulating dataset with labels
print('\n\nSimulate Dataset with Labels')
print('------------------------------------------')
X = np.random.rand(5, 3)  # 5 samples, 3 features
y = np.array([0, 1, 0, 1, 1])
print('Features (X):\n', X)
print('Labels (y):', y)

# Example 3: Normalize features
print('\n\nNormalize Features')
print('------------------------------------------')
X_mean = X.mean(axis=0)
X_std = X.std(axis=0)
X_norm = (X - X_mean) / X_std
print('Normalized Features:\n', X_norm)

# Example 4: Compute distance between samples
print('\n\nCompute Euclidean Distance')
print('------------------------------------------')
a = np.array([1, 2])
b = np.array([4, 6])
dist = np.linalg.norm(a - b)
print('Distance between a and b:', dist)

# Example 5: One-hot encoding of labels
print('\n\nOne-Hot Encoding')
print('------------------------------------------')
labels = np.array([0, 1, 2])
one_hot = np.eye(3)[labels]
print('One-hot encoded labels:\n', one_hot)

# Example 6: Confusion matrix calculation (mock)
print('\n\nConfusion Matrix (Mock)')
print('------------------------------------------')
true = np.array([1, 0, 1, 1, 0])
pred = np.array([1, 0, 0, 1, 1])
TP = np.sum((true == 1) & (pred == 1))
TN = np.sum((true == 0) & (pred == 0))
FP = np.sum((true == 0) & (pred == 1))
FN = np.sum((true == 1) & (pred == 0))
print(f'TP: {TP}, TN: {TN}, FP: {FP}, FN: {FN}')

# Example 7: Simulate weight initialization
print('\n\nWeight Initialization')
print('------------------------------------------')
weights = np.random.randn(3, 1) * 0.01
print('Weights initialized with small random values:')
print(weights)

# Example 8: Sigmoid activation function
print('\n\nSigmoid Activation Function')
print('------------------------------------------')
def sigmoid(x):
    return 1 / (1 + np.exp(-x))
x_vals = np.array([-2.0, 0.0, 2.0])
print('Sigmoid Output:', sigmoid(x_vals))

# Example 9: Softmax function
print('\n\nSoftmax Function')
print('------------------------------------------')
def softmax(x):
    exp_x = np.exp(x - np.max(x))
    return exp_x / exp_x.sum()
logits = np.array([2.0, 1.0, 0.1])
print('Softmax Output:', softmax(logits))

# Example 10: Vectorized Loss Calculation (MSE)
print('\n\nMean Squared Error')
print('------------------------------------------')
preds = np.array([2.5, 0.0, 2.1, 1.4])
targets = np.array([3.0, -0.5, 2.0, 1.0])
mse = np.mean((preds - targets)**2)
print('Mean Squared Error:', mse)