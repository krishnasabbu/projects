#import numpy library
import numpy as np

#Create Arrays
arr = np.array([1, 2, 3])

#Array Operations(Element-wise)
print('\n\nArray Operations(Element-wise)')
print('------------------------------------------')

a = np.array([1, 2, 3])
b = np.array([4, 5, 6])
result = a + b  
print('A :',a)
print('B :',b)
print('A + B :',result)# [5, 7, 9]

#Matrix Multiplication
print('\n\nMatrix Multiplication')
print('------------------------------------------')

a = np.array([[1, 2], [3, 4]])
b = np.array([[5, 6], [7, 8]])
result = np.dot(a, b)
print('\nA :',a)
print('\nB :',b)
print('\nA .B :')
print(result)

#Statistical Functions
print('\n\nStatistical Functions')
print('------------------------------------------')
data = np.array([10, 20, 30])
mean = np.mean(data)
std = np.std(data)

print('Data :',data)
print('Mean :',mean)
print('Standard deviation :',std)

#Boolean Indexing
print('\n\nBoolean Indexing')
print('------------------------------------------')
arr = np.array([5, 10, 15, 20])
filtered = arr[arr > 10]  # [15, 20]
print('Data :',data)
print('Filter > 10:',filtered)

#Reshape Arrays
print('\n\nReshape Arrays')
print('------------------------------------------')
arr = np.array([1, 2, 3, 4, 5, 6])
reshaped = arr.reshape((2, 3))
print('Data :',data)
print('Reshaped :',reshaped)

#Generate Random Numbers
print('\n\nGenerate Random Number')
print('------------------------------------------')

rand_arr = np.random.rand(3, 3)  # Uniform distribution
print('Random Number [np.random.rand(3, 3)]:',rand_arr)

#Identity and Zero Matrices
print('\n\nIndentiy and Zero Matirces')
print('------------------------------------------')

I = np.eye(3)          # 3x3 Identity matrix
Z = np.zeros((2, 2))   # 2x2 Zero matrix

print('\n3x3 Identity matrix [np.eye(3)]\n',I)
print('\n\n2x2 Zero matrix [np.zeros((2, 2))]\n',Z)


#Multiply Matrices
print('\n\nMultiply Matrices')
print('------------------------------------------')
a = np.array([1, 2, 3])
b = 2
result = a * b  # [2, 4, 6]
print('A :',a)
print('B :',b)
print('A * B :',result)