from sklearn.linear_model import LinearRegression
import numpy as np

# Create synthetic data
X = np.array([[1], [2], [3], [4]])
y = np.array([2, 4, 6, 8])

# Train Linear Regression model
model = LinearRegression()
model.fit(X, y)

print('\nLinearRegression:::')
print('-------------------------------------------------')

# Output model parameters
print("Coefficient:", model.coef_)
print("Intercept:", model.intercept_)

# Make a prediction
new_x = np.array([[5]])
prediction = model.predict(new_x)
print("Prediction for input 5:", prediction)


print('\n\n\nRandomForestClassifier:::')
print('-------------------------------------------------')

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report

# Load iris dataset
iris = load_iris()
X = iris.data
y = iris.target

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)

# Train model
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Predict and evaluate
y_pred = model.predict(X_test)
print("Classification Report:")
print(classification_report(y_test, y_pred))