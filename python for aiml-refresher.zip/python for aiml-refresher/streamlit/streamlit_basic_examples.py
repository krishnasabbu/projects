# streamlit_basic_examples.py
# This file demonstrates the basic functionality of Streamlit for building simple interactive web apps.


import streamlit as st
import pandas as pd
import numpy as np
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

# ---------------------------------------------------------------------------------------
# 1. DISPLAYING TEXT
# ---------------------------------------------------------------------------------------

# Displaying a large title at the top of the web app.
# Use this for the main heading or app name.
st.title("🚀 Streamlit Basic Examples")

# Display a secondary heading for section grouping.
# Good for organizing your app into readable sections.
st.header("1. Display Text")

# Markdown allows rich formatting like bold, italic, links, and more.
# It's useful for adding explanations, instructions, or context to users.
st.markdown("Welcome to the **Streamlit Demo**. This is a simple example showing how to use text.")

# ---------------------------------------------------------------------------------------
# 2. INPUT WIDGETS
# ---------------------------------------------------------------------------------------

st.header("2. Input Widgets")

# Text input lets the user enter a string.
# It’s useful for capturing things like names, keywords, etc.
name = st.text_input("Enter your name:")

# Number input restricts input to numbers within a specific range.
# You can define minimum, maximum, and step values.
age = st.number_input("Enter your age:", min_value=1, max_value=100)

# Checkbox is a boolean toggle. Returns True when checked.
# Often used to trigger conditional displays.
show_greeting = st.checkbox("Show greeting")

# Selectbox lets the user choose one option from a dropdown menu.
# Great for categorical choices like language, model type, etc.
language = st.selectbox("Preferred language:", ["Python", "Java", "C++"])

# Display custom greeting based on checkbox status.
if show_greeting:
    st.write(f"👋 Hello {name}, you're {age} years old and you love {language}!")

# ---------------------------------------------------------------------------------------
# 3. DISPLAYING DATA
# ---------------------------------------------------------------------------------------

st.header("3. Display Data")

# Creating a sample DataFrame using pandas.
# This simulates tabular data like you'd find in a CSV or database.
data = pd.DataFrame({
    'Name': ['Alice', 'Bob', 'Charlie'],
    'Age': [24, 27, 22]
})

# st.dataframe renders the DataFrame as an interactive table.
# You can scroll, search, and sort the data in the UI.
st.dataframe(data)

# Displaying JSON is useful for showing structured data or API responses.
# It preserves formatting and indentation for easy reading.
person = {"name": "Alice", "age": 24, "city": "New York"}
st.json(person)

# ---------------------------------------------------------------------------------------
# 4. CHARTING
# ---------------------------------------------------------------------------------------

st.header("4. Charts")

# Generating random numeric data for charting.
# This simulates actual measurements or prediction scores.
chart_data = pd.DataFrame(
    np.random.randn(20, 3),
    columns=['A', 'B', 'C']
)

# Line chart displays trends over an index or time.
# Each column becomes one line on the graph.
st.subheader("Line Chart")
st.line_chart(chart_data)

# Bar chart shows vertical bars for each value.
# Useful for comparing quantities or categories.
st.subheader("Bar Chart")
st.bar_chart(chart_data)

# ---------------------------------------------------------------------------------------
# 5. FILE UPLOAD
# ---------------------------------------------------------------------------------------

st.header("5. File Upload")

# File uploader lets users upload files, e.g., CSV, Excel, images.
# It returns a file-like object that can be passed into pandas.
uploaded_file = st.file_uploader("Upload a CSV file")

# Check if the user uploaded a file.
# If so, read it as a DataFrame and display it.
if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)
    st.write("📄 Uploaded Data:")
    st.dataframe(df)

# ---------------------------------------------------------------------------------------
# 6. CONDITIONAL LOGIC
# ---------------------------------------------------------------------------------------

st.header("6. Conditional Logic")

# Radio button forces selection of one option from a small group.
# Good for branching logic, filters, or display options.
choice = st.radio("Choose an option:", ['Show Image', 'Show Text'])

# Depending on what the user selects, display different outputs.
if choice == 'Show Image':
    # Display a placeholder image from a URL.
    # You can also use a local path or upload.
    st.image("https://via.placeholder.com/150", caption="Sample Image")
else:
    st.write("✅ You selected to show text instead of an image.")

# ---------------------------------------------------------------------------------------
# 7. LAYOUT FEATURES
# ---------------------------------------------------------------------------------------

st.header("7. Layout Features")

# st.columns allows side-by-side widgets or content.
# This helps organize complex UIs and dashboards.
col1, col2 = st.columns(2)

# Each column can contain independent widgets.
# Here we place buttons in two columns.
with col1:
    st.button("Left Column")

with col2:
    st.button("Right Column")

# Expander is used to show/hide extra details.
# Great for advanced options or documentation without cluttering the UI.
with st.expander("Click to Expand"):
    st.write("This is some hidden info you can reveal by clicking.")



# Show a simple text
st.write("This section demonstrates basic Streamlit components like text, input, and charts.")

# Use a slider widget to pick a value
val = st.slider("Pick a number", 1, 100, 25)
st.write(f"You picked: {val}")

# Show a random data chart
st.write("Below is a line chart of some random data:")
st.line_chart(np.random.randn(10, 2))

# ---------------------------------------------
# 8. Exploratory Data Analysis on Iris Dataset
# ---------------------------------------------

st.subheader("8.EDA on Iris Dataset")

# Load iris dataset
iris = load_iris()
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df["target"] = iris.target

# Display raw data in table form
st.write("### Raw Iris Dataset")
st.dataframe(df.head())

# Show summary stats
st.write("### Statistical Summary")
st.write(df.describe())

# Plot a histogram of a selected feature
feature = st.selectbox("Select feature to plot histogram:", iris.feature_names)
st.write(f"### Histogram of {feature}")
st.bar_chart(df[feature])

# ---------------------------------------------
# 9. Classification with Random Forest
# ---------------------------------------------

st.subheader("9.Train a RandomForest Classifier on Iris Dataset")

# Allow user to select max depth
max_depth = st.slider("Select max depth for RandomForest:", 1, 10, 3)

# Train/test split
X = iris.data
y = iris.target
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)

# Train the model
clf = RandomForestClassifier(max_depth=max_depth)
clf.fit(X_train, y_train)

# Make predictions
y_pred = clf.predict(X_test)

# Display classification report
st.write("### Classification Report")
st.text(classification_report(y_test, y_pred))

# ---------------------------------------------
# 10. Linear Regression Example
# ---------------------------------------------

st.subheader("10.Simple Linear Regression")

# Generate synthetic data
X_lin = np.array([[1], [2], [3], [4]])
y_lin = np.array([2, 4, 6, 8])  # Simple linear relationship

# Train linear regression
lin_model = LinearRegression()
lin_model.fit(X_lin, y_lin)

# Show model parameters
st.write("### Model Coefficients")
st.write("Slope (Coefficient):", lin_model.coef_[0])
st.write("Intercept:", lin_model.intercept_)

# Predict a user-provided value
user_input = st.number_input("Enter a value to predict:", min_value=0, max_value=10, value=5)
predicted = lin_model.predict(np.array([[user_input]]))
st.write(f"### Prediction for input {user_input}: {predicted[0]:.2f}")

# ---------------------------------------------
# 11. Upload CSV for Custom AI/ML
# ---------------------------------------------

st.subheader("11.Upload Your Own CSV for Analysis")

uploaded_file = st.file_uploader("Upload a CSV file", type="csv")

if uploaded_file:
    custom_df = pd.read_csv(uploaded_file)
    st.write("### Uploaded Data")
    st.dataframe(custom_df.head())

    if st.checkbox("Show summary stats"):
        st.write(custom_df.describe())

# ---------------------------------------------
# 12 Streamlit Sidebar for Navigation
# ---------------------------------------------

# Show how sidebars can be used
st.sidebar.title("📁 Sidebar Navigation")
st.sidebar.info("Use this sidebar to interact with widgets and explore models.")

# ---------------------------------------------
# 13. Real-time Inference Simulation (Optional)
# ---------------------------------------------

st.subheader("12.Simulate Real-Time Inference")

st.write("Here, we simulate how a trained model might give real-time predictions on user input.")

input_feature = st.slider("Enter feature (1-10):", 1, 10, 5)
# Simulate prediction (y = 2x + noise)
predicted_value = 2 * input_feature + np.random.randn()
st.write(f"Predicted Output: {predicted_value:.2f}")
