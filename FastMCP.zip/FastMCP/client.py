import asyncio
from fastmcp import Client
from fastmcp.client.transports import SSETransport


async def main():
    # Adjust the client to match your server's transport type
    async with Client(SSETransport("http://localhost:8000/sse")) as client:
        # Call a tool
        result = await client.call_tool("add", {"a": "1", "b": "2"})
        print(result)


if __name__ == "__main__":
    asyncio.run(main())
