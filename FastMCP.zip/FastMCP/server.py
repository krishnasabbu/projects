import logging
from fastmcp import FastMCP
import asyncio

# Enable detailed logging
logging.basicConfig(level=logging.DEBUG)
logging.getLogger("asyncio").setLevel(logging.DEBUG)

asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
mcp = FastMCP("Basic MCP Server")


@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers"""
    return a + b


@mcp.resource("config://app-version")
def get_app_version() -> str:
    """Returns the application version."""
    return "v2.1.0"


if __name__ == "__main__":
    mcp.run(transport="sse", port=8000)
