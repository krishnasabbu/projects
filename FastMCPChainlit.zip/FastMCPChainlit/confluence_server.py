from fastmcp import FastMCP

mcp = FastMCP("Confluence Server")


@mcp.tool()
def add_confluence_page(title: str, content: str) -> str:
    return f"Confluence page added: {title}"


if __name__ == "__main__":
    mcp.run(transport="sse", port=8001)
