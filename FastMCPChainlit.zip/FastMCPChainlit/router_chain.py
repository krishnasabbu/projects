from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from custom import MyCustomLLM

prompt = PromptTemplate.from_template("""
Classify the user's question to either "jira" or "confluence".

Question: {question}
Answer:
""")

llm = MyCustomLLM(api_url="http://localhost:5000/generate")
router_chain = LLMChain(llm=llm, prompt=prompt)

result = router_chain.invoke({"question": "How do I update Jira?"})
print(result)
