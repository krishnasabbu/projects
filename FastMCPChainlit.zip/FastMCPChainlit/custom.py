from langchain_core.language_models.llms import LLM
from langchain_core.outputs import LLMResult
from typing import List, Optional, Any
import requests, asyncio, httpx


class MyCustomLLM(LLM):
    api_url: str

    def _call(self, prompt: str, stop: Optional[List[str]] = None, **kwargs: Any) -> str:

        return "jira"

    async def _acall(self, prompt: str, stop: Optional[List[str]] = None, **kwargs: Any) -> str:
        return "jira"

    @property
    def _llm_type(self) -> str:
        return "my_custom_llm"
