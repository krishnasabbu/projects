import chainlit as cl
from mcp_client import call_correct_server  # From previous step


@cl.on_message
async def main(message: cl.Message):
    # Parse the incoming message to decide which tool to call
    print(message.content)
    tool_args = {"title": "Jira Hitting", "content": message.content}
    result = await call_correct_server(message.content, tool_args)

    print(f"result == = {result}")

    # Return the result back to the user
    await cl.Message(content=result[0].text).send()
