from fastmcp import FastMCP

mcp = FastMCP("Jira Server")


@mcp.tool()
def create_jira_ticket(summary: str, description: str) -> str:
    return f"Jira ticket created: {summary} - {description}"


if __name__ == "__main__":
    mcp.run(transport="sse", port=8002)
