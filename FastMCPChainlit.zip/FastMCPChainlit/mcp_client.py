import asyncio
from fastmcp import Client
from fastmcp.client.transports import SSETransport
from router_chain import router_chain  # From the previous step


async def call_correct_server(question: str, tool_args: dict):
    # Route using LLM
    server_choice = await router_chain.arun(question=question)
    server_choice = server_choice.strip().lower()

    print(f" server_choise   {server_choice}")

    if server_choice == "jira":
        path = "http://127.0.0.1:8001/sse"
        tool_name = "add_confluence_page"
    elif server_choice == "confluence":
        path = "confluence_server.py"
        tool_name = "add_confluence_page"
    else:
        raise ValueError("Unsupported server type")

    # Call the MCP tool
    async with Client(SSETransport(path)) as client:
        result = await client.call_tool(tool_name, tool_args)
        print(result)
        return result


# Example usage
if __name__ == "__main__":
    question = "Can you create a page for the release notes?"
    tool_args = {"title": "Release Notes", "content": "Details about version 1.0"}

    result = asyncio.run(call_correct_server(question, tool_args))
    print(result)
